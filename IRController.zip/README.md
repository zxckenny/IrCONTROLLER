# IR CONTROLLER

Пульты: ИК (ConsumerIrManager) + Bluetooth SPP + Bluetooth BLE.

## Свои базы (импорт: «Файл» или «Вставить»)
1. Flipper Zero `.ir` (протоколы NEC, NECext, Samsung32 и raw) — из IRDB.
2. Наш JSON (один пульт, массив или {"remotes":[...]}):

```json
{
  "name": "Моя ТВ", "transport": "IR",
  "buttons": [
    {"label": "Power", "kind": "nec",     "data": "04 08"},
    {"label": "Vol+",  "kind": "samsung", "data": "07 07"},
    {"label": "Raw",   "kind": "raw",     "data": "9000 4500 560 560 560 1690", "freq": 38000},
    {"label": "Pro",   "kind": "pronto",  "data": "0000 006D 0022 0000 ..."}
  ]
}
```
Bluetooth:
```json
{"name": "Реле", "transport": "SPP", "eol": "\n",
 "buttons": [{"label": "ON", "kind": "text", "data": "ON"}, {"label": "RAW", "kind": "hex", "data": "A0 01 A1"}]}
```
transport: IR | SPP | BLE. kind для ИК: nec, nec32, samsung, raw, pronto. Для BT: text, hex.
