package com.irctl.controller

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Btn(var label: String, var kind: String, var data: String, var freq: Int = 38000) {
    fun toJson(): JSONObject =
        JSONObject().put("label", label).put("kind", kind).put("data", data).put("freq", freq)
}

class Remote(var name: String, var transport: String) {
    val buttons = mutableListOf<Btn>()
    var eol = "\n"
    var uuid = ""

    fun toJson(): JSONObject {
        val a = JSONArray()
        buttons.forEach { a.put(it.toJson()) }
        return JSONObject().put("name", name).put("transport", transport)
            .put("eol", eol).put("uuid", uuid).put("buttons", a)
    }
}

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("irctl", Context.MODE_PRIVATE)

    fun load(): MutableList<Remote> = try {
        val a = JSONArray(sp.getString("remotes", "[]"))
        (0 until a.length()).map { Importer.remoteFrom(a.getJSONObject(it)) }.toMutableList()
    } catch (e: Exception) {
        mutableListOf()
    }

    fun save(l: List<Remote>) {
        val a = JSONArray()
        l.forEach { a.put(it.toJson()) }
        sp.edit().putString("remotes", a.toString()).apply()
    }
}

object Sample {
    fun samsung(): Remote {
        val r = Remote("Samsung TV (пример)", "IR")
        fun k(l: String, cmd: String) = r.buttons.add(Btn(l, "samsung", "07 $cmd"))
        k("⏻", "02"); k("Mute", "0F"); k("Vol +", "07"); k("Vol −", "0B"); k("CH +", "12"); k("CH −", "10")
        return r
    }
}

/** IR: превращает кнопку в (частота, массив длительностей в мкс) */
object Ir {
    fun hexInts(s: String): List<Int> =
        s.replace("0x", "", true).split(Regex("[^0-9A-Fa-f]+")).filter { it.isNotEmpty() }.map { it.toInt(16) }

    fun hexBytes(s: String): List<Int> =
        s.replace("0x", "", true).split(Regex("[^0-9A-Fa-f]+")).filter { it.isNotEmpty() }
            .flatMap { it.chunked(2) }.map { it.toInt(16) }

    private fun frame(bytes: IntArray, h1: Int, h2: Int): IntArray {
        val l = ArrayList<Int>()
        l.add(h1); l.add(h2)
        for (by in bytes) for (i in 0..7) {
            l.add(560)
            l.add(if (((by shr i) and 1) == 1) 1690 else 560)
        }
        l.add(560)
        return l.toIntArray()
    }

    fun build(b: Btn): Pair<Int, IntArray> = when (b.kind) {
        "nec" -> {
            val v = hexInts(b.data)
            val a = v[0]; val c = v[1]
            val bytes = if (a > 255) intArrayOf(a and 255, (a shr 8) and 255, c and 255, c.inv() and 255)
            else intArrayOf(a, a.inv() and 255, c and 255, c.inv() and 255)
            38000 to frame(bytes, 9000, 4500)
        }
        "nec32" -> {
            val v = hexBytes(b.data)
            require(v.size >= 4) { "нужно 4 байта" }
            38000 to frame(intArrayOf(v[0], v[1], v[2], v[3]), 9000, 4500)
        }
        "samsung" -> {
            val v = hexInts(b.data)
            val a = v[0]; val c = v[1]
            38000 to frame(intArrayOf(a, a, c and 255, c.inv() and 255), 4500, 4500)
        }
        "raw" -> {
            val p = b.data.split(Regex("[^0-9]+")).filter { it.isNotEmpty() }.map { it.toInt() }.toIntArray()
            require(p.isNotEmpty()) { "пусто" }
            (if (b.freq > 0) b.freq else 38000) to p
        }
        "pronto" -> pronto(b.data)
        else -> throw IllegalArgumentException("тип ${b.kind}")
    }

    private fun pronto(s: String): Pair<Int, IntArray> {
        val w = hexInts(s)
        require(w.size > 4 && w[0] == 0) { "не Pronto" }
        val unit = w[1] * 0.241246
        val once = w[2]; val rep = w[3]
        val cnt = if (once > 0) once else rep
        val end = minOf(w.size, 4 + cnt * 2)
        val pat = IntArray(end - 4) { (w[4 + it] * unit).toInt() }
        return (1000000.0 / unit).toInt() to pat
    }
}

/** Импорт баз: наш JSON или Flipper Zero .ir */
object Importer {
    fun remoteFrom(o: JSONObject): Remote {
        var t = o.optString("transport", o.optString("type", "IR")).uppercase()
        if (t == "BT" || t == "BLUETOOTH") t = "SPP"
        if (t !in listOf("IR", "SPP", "BLE")) t = "IR"
        val r = Remote(o.optString("name", "Импорт"), t)
        r.eol = o.optString("eol", "\n")
        r.uuid = o.optString("uuid", "")
        val a = o.optJSONArray("buttons") ?: JSONArray()
        for (i in 0 until a.length()) {
            val b = a.getJSONObject(i)
            r.buttons.add(
                Btn(
                    b.optString("label", "?"), b.optString("kind", "raw").lowercase(),
                    b.optString("data", ""), b.optInt("freq", 38000)
                )
            )
        }
        return r
    }

    fun parse(text: String, name: String): List<Remote> {
        val t = text.trim().removePrefix("\uFEFF")
        val list: List<Remote> = when {
            t.startsWith("[") -> {
                val a = JSONArray(t)
                (0 until a.length()).map { remoteFrom(a.getJSONObject(it)) }
            }
            t.startsWith("{") -> {
                val o = JSONObject(t)
                val rs = o.optJSONArray("remotes")
                if (rs != null) (0 until rs.length()).map { remoteFrom(rs.getJSONObject(it)) }
                else listOf(remoteFrom(o))
            }
            else -> listOf(flipper(t, name))
        }
        return list.filter { it.buttons.isNotEmpty() }
    }

    private fun flipper(text: String, name: String): Remote {
        val r = Remote(name, "IR")
        var cur = HashMap<String, String>()
        fun flush() {
            val n = cur["name"]
            if (n != null) {
                val type = cur["type"]?.lowercase()
                if (type == "raw") {
                    r.buttons.add(Btn(n, "raw", cur["data"] ?: "", cur["frequency"]?.toIntOrNull() ?: 38000))
                } else if (type == "parsed") {
                    val a = Ir.hexBytes(cur["address"] ?: "00 00 00 00") + listOf(0, 0, 0, 0)
                    val c = Ir.hexBytes(cur["command"] ?: "00 00 00 00") + listOf(0, 0, 0, 0)
                    fun h(i: Int) = "%02X".format(i)
                    when (cur["protocol"]?.lowercase()) {
                        "nec" -> r.buttons.add(Btn(n, "nec", "${h(a[0])} ${h(c[0])}"))
                        "necext" -> r.buttons.add(Btn(n, "nec32", "${h(a[0])} ${h(a[1])} ${h(c[0])} ${h(c[1])}"))
                        "samsung32" -> r.buttons.add(Btn(n, "samsung", "${h(a[0])} ${h(c[0])}"))
                    }
                }
            }
            cur = HashMap()
        }
        for (line in text.lines()) {
            val l = line.trim()
            if (l.startsWith("#")) { flush(); continue }
            val i = l.indexOf(':')
            if (i < 0) continue
            cur[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim()
        }
        flush()
        return r
    }
}
