package com.irctl.controller

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue

/** Одно активное Bluetooth-подключение: Classic SPP (RFCOMM) или BLE GATT */
@SuppressLint("MissingPermission")
class BtLink(private val ctx: Context, private val onState: (String) -> Unit) {
    private val main = Handler(Looper.getMainLooper())
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var gatt: BluetoothGatt? = null
    private var ch: BluetoothGattCharacteristic? = null
    private val q = ConcurrentLinkedQueue<ByteArray>()
    private var busy = false
    var wantUuid = ""

    private fun state(s: String) { main.post { onState(s) } }

    fun connectSpp(dev: BluetoothDevice) {
        close()
        Thread {
            try {
                val s = dev.createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"))
                BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
                s.connect()
                socket = s
                out = s.outputStream
                state("Подключено: ${dev.name ?: dev.address}")
            } catch (e: Exception) {
                state("Ошибка: ${e.message}")
            }
        }.start()
    }

    fun connectBle(dev: BluetoothDevice) {
        close()
        gatt = if (Build.VERSION.SDK_INT >= 23) dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        else dev.connectGatt(ctx, false, cb)
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                state("Ищу сервисы…")
                g.discoverServices()
            } else {
                ch = null
                state("Отключено")
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            var found: BluetoothGattCharacteristic? = null
            val mask = BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE
            for (s in g.services) {
                val su = s.uuid.toString()
                if (su.startsWith("00001800") || su.startsWith("00001801")) continue
                for (c in s.characteristics) {
                    val ok = if (wantUuid.isNotBlank()) c.uuid.toString().contains(wantUuid.trim(), true)
                    else (c.properties and mask) != 0
                    if (found == null && ok) found = c
                }
            }
            ch = found
            state(if (found != null) "BLE готов (${found.uuid.toString().take(8)})" else "Нет подходящей характеристики")
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            busy = false
            pump()
        }
    }

    @Synchronized
    private fun pump() {
        if (busy) return
        val c = ch ?: return
        val g = gatt ?: return
        val b = q.poll() ?: return
        busy = true
        c.value = b
        c.writeType = if ((c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT else BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        if (!g.writeCharacteristic(c)) busy = false
    }

    fun send(b: ByteArray): Boolean {
        val o = out
        if (o != null) {
            Thread {
                try { o.write(b); o.flush() } catch (e: Exception) { state("Ошибка: ${e.message}") }
            }.start()
            return true
        }
        if (gatt != null && ch != null) {
            var i = 0
            while (i < b.size) { q.add(b.copyOfRange(i, minOf(i + 20, b.size))); i += 20 }
            pump()
            return true
        }
        return false
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        socket = null; out = null; gatt = null; ch = null
        q.clear(); busy = false
    }
}
