package com.irctl.controller

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.text.InputType
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.widget.*

@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private val BG = Color.parseColor("#0E1116")
    private val CARD = Color.parseColor("#1B2029")
    private val KEY = Color.parseColor("#252C38")
    private val ACC = Color.parseColor("#4FC3F7")
    private val ACC2 = Color.parseColor("#0277BD")
    private val WARN = Color.parseColor("#E65100")
    private val TXT = Color.WHITE
    private val DIM = Color.parseColor("#8A94A6")

    private lateinit var store: Store
    private var remotes = mutableListOf<Remote>()
    private var ir: ConsumerIrManager? = null
    private lateinit var link: BtLink
    private var current: Remote? = null
    private var editMode = false
    private var statusView: TextView? = null
    private var btStatus = "Не подключено"

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        store = Store(this)
        remotes = store.load()
        if (remotes.isEmpty()) { remotes.add(Sample.samsung()); save() }
        ir = getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
        link = BtLink(this) { setStatus(it) }
        if (Build.VERSION.SDK_INT >= 23) {
            val p = ArrayList<String>()
            if (Build.VERSION.SDK_INT >= 31) {
                p.add(Manifest.permission.BLUETOOTH_CONNECT); p.add(Manifest.permission.BLUETOOTH_SCAN)
            } else p.add(Manifest.permission.ACCESS_FINE_LOCATION)
            requestPermissions(p.toTypedArray(), 1)
        }
        home()
    }

    override fun onDestroy() { link.close(); super.onDestroy() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (current != null) home() else super.onBackPressed() }

    // ---------- helpers ----------
    private fun save() = store.save(remotes)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun hor() = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
    private fun setStatus(s: String) { btStatus = s; statusView?.text = s }
    private fun tv(t: String, size: Float = 16f, color: Int = TXT, bold: Boolean = false) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD) }

    private fun btn(t: String, color: Int = KEY, onClick: () -> Unit) = TextView(this).apply {
        text = t; gravity = Gravity.CENTER; textSize = 15f; setTextColor(TXT); background = bg(color)
        setPadding(dp(10), dp(14), dp(10), dp(14)); setOnClickListener { onClick() }
    }

    private fun w1(h: Int = -2) = LinearLayout.LayoutParams(0, h, 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }
    private fun wrap() = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(6)) }

    private fun root(): LinearLayout = col().apply {
        setBackgroundColor(BG); setPadding(dp(12), dp(12), dp(12), dp(12)); fitsSystemWindows = true
    }

    // ---------- home ----------
    private fun home() {
        current = null; editMode = false; link.close(); btStatus = "Не подключено"; statusView = null
        val r = root()
        r.addView(tv("IR CONTROLLER", 26f, ACC, true))
        r.addView(tv(if (ir?.hasIrEmitter() == true) "ИК-порт найден ✔" else "ИК-порта нет — работает Bluetooth", 13f, DIM))
        val sc = ScrollView(this); val list = col(); sc.addView(list)
        for (rem in remotes.toList()) list.addView(card(rem), wrap())
        r.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = hor()
        bar.addView(btn("+ Пульт", ACC2) { newRemote() }, w1())
        bar.addView(btn("Файл") { pickFile() }, w1())
        bar.addView(btn("Вставить") { pasteImport() }, w1())
        r.addView(bar)
        setContentView(r)
    }

    private fun transportName(t: String) = when (t) { "IR" -> "ИК"; "SPP" -> "Bluetooth SPP"; else -> "Bluetooth BLE" }

    private fun card(rem: Remote): View = col().apply {
        background = bg(CARD); setPadding(dp(16), dp(14), dp(16), dp(14))
        addView(tv(rem.name, 18f, TXT, true))
        addView(tv("${transportName(rem.transport)} • кнопок: ${rem.buttons.size}", 13f, DIM))
        setOnClickListener { showRemote(rem) }
        setOnLongClickListener {
            AlertDialog.Builder(this@MainActivity).setTitle(rem.name)
                .setItems(arrayOf("Поделиться (JSON)", "Дублировать", "Удалить")) { _, i ->
                    when (i) {
                        0 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"; putExtra(Intent.EXTRA_TEXT, rem.toJson().toString(2))
                        }, "Поделиться"))
                        1 -> { remotes.add(Importer.remoteFrom(rem.toJson()).apply { name = rem.name + " копия" }); save(); home() }
                        2 -> { remotes.remove(rem); save(); home() }
                    }
                }.show()
            true
        }
    }

    private fun newRemote() {
        val box = col().apply { setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Название (например, Телевизор)" }
        val sp = Spinner(this)
        val names = listOf("ИК (инфракрасный)", "Bluetooth SPP (HC-05, ESP32 Classic)", "Bluetooth BLE (ESP32, nRF)")
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        box.addView(name); box.addView(sp)
        AlertDialog.Builder(this).setTitle("Новый пульт").setView(box)
            .setPositiveButton("Создать") { _, _ ->
                val t = listOf("IR", "SPP", "BLE")[sp.selectedItemPosition]
                val r = Remote(name.text.toString().ifBlank { "Пульт" }, t)
                remotes.add(r); save(); showRemote(r)
            }.setNegativeButton("Отмена", null).show()
    }

    // ---------- import ----------
    private fun pickFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }, 42)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, d: Intent?) {
        super.onActivityResult(req, res, d)
        if (req != 42 || res != RESULT_OK) return
        val u = d?.data ?: return
        try {
            val text = contentResolver.openInputStream(u)!!.use { it.readBytes().toString(Charsets.UTF_8) }
            var nm = "Импорт"
            contentResolver.query(u, null, null, null, null)?.use { c ->
                val ix = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (c.moveToFirst() && ix >= 0) nm = c.getString(ix).substringBeforeLast('.')
            }
            importText(text, nm)
        } catch (e: Exception) { toast("Ошибка: ${e.message}") }
    }

    private fun pasteImport() {
        val et = EditText(this).apply { hint = "JSON или текст .ir (Flipper)"; minLines = 6; gravity = Gravity.TOP }
        AlertDialog.Builder(this).setTitle("Вставить базу").setView(et)
            .setPositiveButton("Импорт") { _, _ -> importText(et.text.toString(), "Импорт") }
            .setNegativeButton("Отмена", null).show()
    }

    private fun importText(text: String, name: String) {
        try {
            val l = Importer.parse(text, name)
            if (l.isEmpty()) { toast("Не нашёл ни одной кнопки"); return }
            remotes.addAll(l); save(); home(); toast("Добавлено пультов: ${l.size}")
        } catch (e: Exception) { toast("Не удалось прочитать: ${e.message}") }
    }

    // ---------- remote screen ----------
    private fun showRemote(r: Remote) {
        current = r
        link.wantUuid = r.uuid
        val root = root()
        val top = hor()
        top.addView(btn("‹") { home() }, LinearLayout.LayoutParams(dp(48), -2))
        top.addView(tv(r.name, 20f, TXT, true), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) })
        top.addView(btn("⚙") { remoteSettings(r) }, LinearLayout.LayoutParams(dp(48), -2).apply { rightMargin = dp(6) })
        top.addView(btn(if (editMode) "Готово" else "Правка", if (editMode) WARN else KEY) {
            editMode = !editMode; showRemote(r)
        }, LinearLayout.LayoutParams(-2, -2))
        root.addView(top)

        if (r.transport != "IR") {
            val row = hor()
            row.addView(btn("Подключить", ACC2) { pickDevice(r) }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, dp(8), dp(10), dp(8)) })
            statusView = tv(btStatus, 13f, DIM)
            row.addView(statusView)
            root.addView(row)
        } else statusView = null

        val sc = ScrollView(this); val grid = col(); sc.addView(grid)
        r.buttons.chunked(3).forEach { rb ->
            val row = hor()
            rb.forEach { b -> row.addView(keyView(r, b), LinearLayout.LayoutParams(0, dp(76), 1f).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }) }
            repeat(3 - rb.size) { row.addView(View(this), LinearLayout.LayoutParams(0, dp(76), 1f)) }
            grid.addView(row)
        }
        grid.addView(btn("+ Кнопка", CARD) { editButton(r, null) }, wrap())
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f))

        if (r.transport != "IR") {
            val t = hor()
            val et = EditText(this).apply { hint = "Своя команда…"; setTextColor(TXT); setHintTextColor(DIM); setSingleLine() }
            t.addView(et, LinearLayout.LayoutParams(0, -2, 1f))
            t.addView(btn("➤") {
                val s = et.text.toString()
                if (s.isNotEmpty() && !link.send((s + r.eol).toByteArray())) toast("Нет подключения")
            }, LinearLayout.LayoutParams(dp(56), -2))
            root.addView(t)
        }
        setContentView(root)
    }

    private fun keyView(r: Remote, b: Btn): View = TextView(this).apply {
        text = b.label; gravity = Gravity.CENTER; textSize = 16f; setTextColor(TXT)
        background = bg(if (editMode) WARN else KEY, 16)
        setOnClickListener { if (editMode) editButton(r, b) else fire(r, b) }
    }

    private fun fire(r: Remote, b: Btn) {
        window.decorView.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        if (r.transport == "IR") {
            val m = ir
            if (m == null || !m.hasIrEmitter()) { toast("На телефоне нет ИК-порта"); return }
            try { val (f, p) = Ir.build(b); m.transmit(f, p) } catch (e: Exception) { toast("Неверный код: ${e.message}") }
        } else {
            val bytes = try {
                if (b.kind == "hex") Ir.hexBytes(b.data).map { it.toByte() }.toByteArray()
                else (b.data + r.eol).toByteArray()
            } catch (e: Exception) { toast("Неверные данные"); return }
            if (!link.send(bytes)) toast("Нет подключения — нажми «Подключить»")
        }
    }

    private val HELP = mapOf(
        "nec" to "Адрес и команда в HEX: 04 08 (адрес больше FF = 16 бит)",
        "nec32" to "4 байта HEX как в кадре: 04 FB 08 F7",
        "samsung" to "Адрес и команда в HEX: 07 02",
        "raw" to "Длительности в мкс: 9000 4500 560 560 …",
        "pronto" to "Pronto HEX: 0000 006D 0022 …",
        "text" to "Текст (в конце добавится окончание строки из ⚙)",
        "hex" to "Байты HEX: A0 01 A1"
    )

    private fun editButton(r: Remote, b: Btn?) {
        val kinds = if (r.transport == "IR") listOf("nec", "nec32", "samsung", "raw", "pronto") else listOf("text", "hex")
        val box = col().apply { setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { hint = "Название"; setText(b?.label ?: "") }
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, kinds)
        if (b != null) sp.setSelection(kinds.indexOf(b.kind).coerceAtLeast(0))
        val data = EditText(this).apply { hint = "Данные"; setText(b?.data ?: "") }
        val fr = EditText(this).apply {
            hint = "Частота, Гц (для raw)"; inputType = InputType.TYPE_CLASS_NUMBER; setText((b?.freq ?: 38000).toString())
        }
        val help = tv("", 12f, DIM)
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { help.text = HELP[kinds[pos]] ?: "" }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        box.addView(name); box.addView(sp); box.addView(data); box.addView(help)
        if (r.transport == "IR") box.addView(fr)
        val d = AlertDialog.Builder(this).setTitle(if (b == null) "Новая кнопка" else "Кнопка").setView(box)
            .setPositiveButton("OK") { _, _ ->
                val nb = b ?: Btn("", "", "").also { r.buttons.add(it) }
                nb.label = name.text.toString().ifBlank { "?" }
                nb.kind = kinds[sp.selectedItemPosition]
                nb.data = data.text.toString().trim()
                nb.freq = fr.text.toString().toIntOrNull() ?: 38000
                save(); showRemote(r)
            }.setNegativeButton("Отмена", null)
        if (b != null) d.setNeutralButton("Удалить") { _, _ -> r.buttons.remove(b); save(); showRemote(r) }
        d.show()
    }

    private fun remoteSettings(r: Remote) {
        val box = col().apply { setPadding(dp(20), dp(8), dp(20), 0) }
        val name = EditText(this).apply { setText(r.name); hint = "Название" }
        box.addView(name)
        val eols = listOf("" to "Без окончания", "\n" to "\\n (LF)", "\r\n" to "\\r\\n (CRLF)")
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, eols.map { it.second })
        sp.setSelection(eols.indexOfFirst { it.first == r.eol }.coerceAtLeast(0))
        val uu = EditText(this).apply { hint = "UUID характеристики BLE (пусто = авто)"; setText(r.uuid) }
        if (r.transport != "IR") { box.addView(tv("Окончание строки", 12f, DIM)); box.addView(sp) }
        if (r.transport == "BLE") box.addView(uu)
        AlertDialog.Builder(this).setTitle("Настройки пульта").setView(box)
            .setPositiveButton("OK") { _, _ ->
                r.name = name.text.toString().ifBlank { r.name }
                r.eol = eols[sp.selectedItemPosition].first
                r.uuid = uu.text.toString().trim()
                save(); showRemote(r)
            }.setNegativeButton("Отмена", null).show()
    }

    // ---------- bluetooth ----------
    private fun pickDevice(r: Remote) {
        val ad = BluetoothAdapter.getDefaultAdapter()
        if (ad == null || !ad.isEnabled) { toast("Включи Bluetooth"); return }
        link.wantUuid = r.uuid
        if (r.transport == "SPP") {
            val devs = ad.bondedDevices.toList()
            if (devs.isEmpty()) { toast("Сначала спарь устройство в настройках Bluetooth"); return }
            AlertDialog.Builder(this).setTitle("Выбери устройство")
                .setItems(devs.map { "${it.name ?: "?"}\n${it.address}" }.toTypedArray()) { _, i ->
                    setStatus("Подключаюсь…"); link.connectSpp(devs[i])
                }.show()
        } else scanBle()
    }

    private fun scanBle() {
        val sc = BluetoothAdapter.getDefaultAdapter()?.bluetoothLeScanner
        if (sc == null) { toast("BLE недоступен"); return }
        val found = LinkedHashMap<String, BluetoothDevice>()
        val cb = object : ScanCallback() {
            override fun onScanResult(t: Int, res: ScanResult) { found[res.device.address] = res.device }
        }
        sc.startScan(cb)
        setStatus("Сканирую 5 сек…")
        Handler(Looper.getMainLooper()).postDelayed({
            try { sc.stopScan(cb) } catch (_: Exception) {}
            val devs = found.values.toList()
            if (devs.isEmpty()) { setStatus("Ничего не найдено"); return@postDelayed }
            setStatus("Не подключено")
            AlertDialog.Builder(this).setTitle("BLE устройства")
                .setItems(devs.map { "${it.name ?: "(без имени)"}\n${it.address}" }.toTypedArray()) { _, i ->
                    setStatus("Подключаюсь…"); link.connectBle(devs[i])
                }.show()
        }, 5000)
    }
}
